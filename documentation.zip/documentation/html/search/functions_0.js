var searchData=
[
  ['get_5ftangent',['get_tangent',['../classSacado__Wrapper_1_1SymTensor.html#ab97427c3b5cab279e58607cf431ab262',1,'Sacado_Wrapper::SymTensor']]]
];
